﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_11
{
    public class Book
    {
        private string title;
        private string author;
        private string genre;
        private int countOfCopies;
        private int countOfOccupiedTimes;

        public int CountOfOccupiedTimes
        {
            get { return this.countOfOccupiedTimes; }
            set
            {
                if (this.countOfOccupiedTimes < 0)
                {
                    throw new ArgumentException("The count of occupied times cannot be a neagtive number!");
                }
                else
                {
                    this.countOfOccupiedTimes = value;
                }
            }
        }

        public int CountOfCopies
        {
            get { return this.countOfCopies; }
            set
            {
                if (this.countOfCopies < 0)
                {
                    throw new ArgumentException("The count of coppies cannot be a neagtive number!");
                }
                else
                {
                    this.countOfCopies = value;
                }
            }
        }

        public string Genre
        {
            get { return this.genre; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The genre name cannot be null or empty!");
                }
                else
                {
                    this.genre = value;
                }
            }
        }

        public string Author
        {
            get { return this.author; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The author name cannot be null or empty!");
                }
                else
                {
                    this.author = value;
                }
            }
        }

        public string Title
        {
            get { return this.title; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The title cannot be null or empty!");
                }
                else
                {
                    this.title = value;
                }
            }
        }

        public Book(string title, string author, string genre, int countOfCopies, int countOfOccupiedTimes)
        {
            this.Title = title;
            this.Author = author;
            this.Genre = genre;
            this.CountOfCopies = countOfCopies;
            this.CountOfOccupiedTimes = countOfOccupiedTimes;
        }
    }
}
