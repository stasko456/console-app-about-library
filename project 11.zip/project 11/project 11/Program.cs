﻿using project_11;

class Program
{
    public static List<Book> books = new List<Book>();
    public static List<Reader> readers = new List<Reader>();
    public static List<Borrowing> borrowings = new List<Borrowing>();
    public static List<string> menu = new List<string>();

    public static void Main(string[] argms)
    {
        try
        {
            menu.Add("---------------------------------------------");
            menu.Add("Menu with commands:");
            menu.Add("1. Insert info about books;");
            menu.Add("2. Insert info about readers;");
            menu.Add("3. Insert info about readers borrowing books;");
            menu.Add("4. Select all the books from the library;");
            menu.Add("5. Select all the readers;");
            menu.Add("6. Select all the books borrowed from a specific reader;");
            menu.Add("7. Select all readers with borrowed books;");
            menu.Add("8. Select books the are not borrowed yet;");
            menu.Add("9. Select books that are returned late;");
            menu.Add("10. Select the book that is the most borrowed;");
            menu.Add("Write 'End' to stop the program!");
            menu.Add("---------------------------------------------");

            foreach (string line in menu)
            {
                Console.WriteLine(line);
            }

            Menu();
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }

    public static void InsertBooks()
    {
        Console.Clear();
        Console.WriteLine("---------------------------------------------");
        Console.WriteLine("Insert info about the books in the library:");
        Console.WriteLine("{Book's title}; {book's author}; {book's genre}; {count of copies}; {count of occupied times};");
        Console.WriteLine("Write 'Stop' to continue with the program!");
        Console.WriteLine("---------------------------------------------");
        
        string[] input = Console.ReadLine().Split(';').ToArray();
        while (input[0] != "Stop")
        {
            Book book = new Book(input[0], input[1], input[2], int.Parse(input[3]), int.Parse(input[4]));
            if (book != null)
            {
                if (!books.Contains(book))
                {
                    books.Add(book);
                }
                else
                {
                    throw new ArgumentException("The book is already added to the library!");
                }
            }
            else
            {
                throw new ArgumentException("The book is null!");
            }
            input = Console.ReadLine().Split(';').ToArray();
        }

        if (input[0] == "Stop")
        {
            Console.Clear();
        }
    }

    public static void InsertReaders()
    {
        Console.Clear();
        Console.WriteLine("---------------------------------------------");
        Console.WriteLine("Insert info about the readers:");
        Console.WriteLine("{Reader's name}; {reader's id}; {reader's age};");
        Console.WriteLine("Write 'Stop' to continue with the program!");
        Console.WriteLine("---------------------------------------------");

        string[] input = Console.ReadLine().Split(';').ToArray();
        
        while (input[0] != "Stop")
        {

            Reader reader = new Reader(input[0], int.Parse(input[1]), int.Parse(input[2]));
            if (reader != null)
            {
                if (!readers.Contains(reader))
                {
                    readers.Add(reader);
                }
                else
                {
                    throw new ArgumentException("The reader is already added to the library!");
                }
            }
            else
            {
                throw new ArgumentException("The reader is null!");
            }

            Console.WriteLine("---------------------------------------------");
            Console.WriteLine("Does the reader want to borrow any books? {Y} or {N}");
            string answer = Console.ReadLine();
            Console.WriteLine("---------------------------------------------");

            if (answer == "Y")
            {
                Console.WriteLine("Write the names of the books that are going to be borrowed, splitted with ';'!");
                Console.WriteLine("---------------------------------------------");
                string[] borrowedBooks = Console.ReadLine().Split(';').ToArray();
                for (int i = 0; i < borrowedBooks.Length; i++)
                {
                    Book book = books.Where(x => x.Title == borrowedBooks[i]).FirstOrDefault();
                    if (book != null)
                    {
                        if (books.Contains(book))
                        {
                            reader.BorrowedBooks.Add(book);
                            Console.WriteLine("Books added successfully to the reader's list of borrowed books!");
                        }
                        else
                        {
                            throw new ArgumentException("The book is not contained in the library!");
                        }
                    }
                    else
                    {
                        throw new ArgumentException("The book is null!");
                    }
                }
                Console.WriteLine("---------------------------------------------");
            }

            Console.Clear();
            Console.WriteLine("---------------------------------------------");
            Console.WriteLine("Insert info about the readers:");
            Console.WriteLine("{Reader's name}; {reader's id}; {reader's age};");
            Console.WriteLine("---------------------------------------------");

            input = Console.ReadLine().Split(';').ToArray();
        }

        if (input[0] == "Stop")
        {
            Console.Clear();
        }
    }

    public static void InsertBorrowings()
    {
        Console.Clear();
        Console.WriteLine("---------------------------------------------");
        Console.WriteLine("Insert info about the borrowings:");
        Console.WriteLine("{Book's title}; {reader's name}; {borrowing date is today's date}; {return date is 30 days after today's date};");
        Console.WriteLine("Write 'Stop' to continue with the program!");
        Console.WriteLine("---------------------------------------------");

        string[] input = Console.ReadLine().Split(';').ToArray();

        while (input[0] != "Stop")
        {
            Book book = books.Where(x => x.Title == input[0]).FirstOrDefault();
            if (book != null)
            {
                if (!books.Contains(book))
                {
                    throw new ArgumentException("The book is not contained in the library!");
                }
            }
            else
            {
                throw new ArgumentException("The book is null!");
            }

            Reader reader = readers.Where(x => x.Name == input[1]).FirstOrDefault();
            if (reader != null)
            {
                if (!readers.Contains(reader))
                {
                    throw new ArgumentException("The reader is not contained in the library!");
                }
            }
            else
            {
                throw new ArgumentException("The reader is null!");
            }

            Random r = new Random();

            DateTime borrowingDate = DateTime.Now;
            DateTime returnDate = borrowingDate.AddDays(r.Next(1,41));

            Borrowing borrowing = new Borrowing(book, reader, borrowingDate, returnDate);

            input = Console.ReadLine().Split(';').ToArray();
        }

        if (input[0] == "Stop")
        {
            Console.Clear();
        }
    }

    public static void SelectAllBooks()
    {
        Console.Clear();
        Console.WriteLine("---------------------------------------------");
        Console.WriteLine("Info about every book in the library:");
        Console.WriteLine("---------------------------------------------");

        foreach (Book book in books)
        {
            Console.WriteLine($"Title:{book.Title}, author:{book.Author}, genre:{book.Genre}, count of coppies:{book.CountOfCopies}, count of occupied times:{book.CountOfOccupiedTimes}");
        }

        Console.WriteLine("---------------------------------------------");
        Console.WriteLine("Write 'continue' to move on with the program:");
        Console.WriteLine("---------------------------------------------");

        string input = Console.ReadLine();
        if (input == "continue")
        {
            Console.Clear();
        }
    }

    public static void SelectAllReaders()
    {
        Console.Clear();
        Console.WriteLine("---------------------------------------------");
        Console.WriteLine("Info about every reader in the library:");
        Console.WriteLine("---------------------------------------------");

        foreach (Reader reader in readers)
        {
            Console.WriteLine($"Name:{reader.Name}, ID:{reader.Id}, age:{reader.Age}");
        }

        Console.WriteLine("---------------------------------------------");
        Console.WriteLine("Write 'continue' to move on with the program:");
        Console.WriteLine("---------------------------------------------");

        string input = Console.ReadLine();
        if (input == "continue")
        {
            Console.Clear();
        }
    }

    public static void BooksBorrowedBySpecificReader()
    {
        Console.Clear();
        Console.WriteLine("Enter a name of a specific reader:");
        string readerName = Console.ReadLine();
        Console.WriteLine("---------------------------------------------");
        Console.WriteLine("Books borrowed by specific reader:");
        Console.WriteLine("---------------------------------------------");

        Reader reader = readers.Where(x => x.Name == readerName).FirstOrDefault();

        foreach (Book book in reader.BorrowedBooks)
        {
            Console.WriteLine($"Title:{book.Title}, author:{book.Author}, genre:{book.Genre}, count of copies:{book.CountOfCopies}, count of occupied times:{book.CountOfOccupiedTimes}");
        }
        Console.WriteLine("---------------------------------------------");
        Console.WriteLine("Write 'continue' to move on with the program:");
        Console.WriteLine("---------------------------------------------");

        string input = Console.ReadLine();
        if (input == "continue")
        {
            Console.Clear();
        }
    }

    public static void ReadersWithBorrowedBooks()
    {
        Console.Clear();
        Console.WriteLine("---------------------------------------------");
        Console.WriteLine("Readers with borrowed books:");
        Console.WriteLine("---------------------------------------------");

        foreach (Reader reader in readers)
        {
            if (reader.BorrowedBooks.Count > 0)
            {
                Console.WriteLine($"Name:{reader.Name}");
            }
        }
        Console.WriteLine("---------------------------------------------");
        Console.WriteLine("Write 'continue' to move on with the program:");
        Console.WriteLine("---------------------------------------------");

        string input = Console.ReadLine();
        if (input == "continue")
        {
            Console.Clear();
        }
    }

    public static void AllNonBorrowedBooks()
    {
        Console.Clear();
        Console.WriteLine("---------------------------------------------");
        Console.WriteLine("Books that are not borrowed:");
        Console.WriteLine("---------------------------------------------");

        foreach(Book book in books)
        {
            DateTime maxDay = DateTime.Now.AddDays(-30);

            foreach (Borrowing borrowing in borrowings)
            {
                if (maxDay > borrowing.DateOfBorrowing && borrowing.DateOfReturn == null)
                {
                    Console.WriteLine($"Tit{borrowing.Book.Title}, {borrowing.Reader.Name}, {borrowing.ReturnDate}");
                }
            }
        }

        Console.WriteLine("---------------------------------------------");
        Console.WriteLine("Write 'continue' to move on with the program:");
        Console.WriteLine("---------------------------------------------");

        string input = Console.ReadLine();
        if (input == "continue")
        {
            Console.Clear();
        }
    }

    public static void Menu()
    {
        string[] input = Console.ReadLine().Split(',').ToArray();

        while (input[0] != "End")
        {
            Console.Clear();
            switch (input[0])
            {
                case "1":
                    InsertBooks();
                    break;
                case "2":
                    InsertReaders();
                    break;
                case "3":
                    InsertBorrowings();
                    break;
                case "4":
                    SelectAllBooks();
                    break;
                case "5":
                    SelectAllReaders();
                    break;
                case "6":
                    BooksBorrowedBySpecificReader();
                    break;
                case "7":
                    ReadersWithBorrowedBooks();
                    break;
                case "8":
                    AllNonBorrowedBooks();
                    break;
                case "9":

                    break;
                case "10":

                    break;
                default:
                    break;
            }

            foreach (string line in menu)
            {
                Console.WriteLine(line);
            }

            input = Console.ReadLine().Split(',').ToArray();
        }
    }
}
