﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_11
{
    public class Reader
    {
        private string name;
        private int id;
        private int age;
        private List<Book> borrowedBooks;

        public List<Book> BorrowedBooks
        {
            get { return this.borrowedBooks; }
            set { this.borrowedBooks = value; }
        }

        public int Age
        {
            get { return this.age; }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("The age cannot be zero or a negative number!");
                }
                else
                {
                    this.age = value;
                }
            }
        }

        public int Id
        {
            get { return this.id; }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("The id cannot be zero or a negative number!");
                }
                else
                {
                    this.id = value;
                }
            }
        }

        public string Name
        {
            get { return this.name; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The name cannot be null or empty!");
                }
                else
                {
                    this.name = value;
                }
            }
        }

        public Reader(string name, int id, int age)
        {
            this.Name = name;
            this.Id = id;
            this.Age = age;
            this.BorrowedBooks = new List<Book>();
        }
    }
}
